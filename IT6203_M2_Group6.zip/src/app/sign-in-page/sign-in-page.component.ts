import { Component, OnInit } from '@angular/core';
import { FormBuilder ,FormControlStatus,FormGroup,Validators} from '@angular/forms';


@Component({
  selector: 'app-sign-in-page',
  templateUrl: './sign-in-page.component.html',
  styleUrls: ['./sign-in-page.component.css']
})
export class SignInPageComponent implements OnInit {
signinForm!:FormGroup;
submitted=false

  constructor(private fb:FormBuilder) { }
  
  ngOnInit(){
    this.signinForm=this.fb.group({
      name:['',[Validators.required,Validators.minLength(6)]],
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required,Validators.minLength(8), Validators.maxLength(10)]
    });
  }
  get signinFormControl() {
    return this.signinForm.controls;
  }
onSubmit(){
  this.submitted=true
  if(this.signinForm.valid){
    return
  }

}
}
