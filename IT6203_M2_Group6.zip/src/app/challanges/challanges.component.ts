import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-challanges',
  templateUrl: './challanges.component.html',
  styleUrls: ['./challanges.component.css']
})
export class ChallangesComponent implements OnInit {
  panelOpenState = false;
  constructor() { }

  ngOnInit(): void {
  }

}
