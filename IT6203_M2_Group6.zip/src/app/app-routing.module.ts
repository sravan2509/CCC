import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChallangesComponent } from './challanges/challanges.component';
import { CodeComponent } from './code/code.component';
import { CodeeditorComponent } from './codeeditor/codeeditor.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ProfileComponent } from './profile/profile.component';
import { SignInPageComponent } from './sign-in-page/sign-in-page.component';


const routes: Routes = [
  {path:'',pathMatch:'full',component:SignInPageComponent},
  {path:'signup',component:SignInPageComponent},
  {path:'login',component:LoginpageComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'code',component:CodeComponent},
  {path:'challanges',component:ChallangesComponent},
  {path:'profile',component:ProfileComponent},
  {path:'codeeditor',component:CodeeditorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[SignInPageComponent,LoginpageComponent,DashboardComponent,CodeComponent,ChallangesComponent,ProfileComponent,CodeeditorComponent]
