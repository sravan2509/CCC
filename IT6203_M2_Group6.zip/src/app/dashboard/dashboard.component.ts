import { Component, OnInit } from '@angular/core';
// export interface People {
//   position: number;
//   name: string;
//   weight: number;
//   symbol: number;
// }

// const peoples: People[] = [

//   {position: 1, name: 'pooja', weight: 1000, symbol: 10},
//   {position: 2, name: 'bhavya', weight: 900, symbol: 9},
//   {position: 3, name: 'divya', weight: 800, symbol: 8},
//   {position: 4, name: 'charan', weight: 700, symbol: 7},
//   {position: 5, name: 'sravan', weight: 600, symbol: 6},
//   {position: 6, name: 'divya', weight: 500, symbol: 5},
//   {position: 7, name: 'pooja', weight: 400, symbol: 4},
//   {position: 8, name: 'bhavya', weight: 300, symbol: 3},
//   {position: 9, name: 'varma', weight: 200, symbol: 2},
//   {position: 10, name: 'pooja', weight: 100, symbol: 1},
// ];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  peoples=[
    {"position":"1","name":"pooja","score":"900","comments":"5"},
    {"position":"2","name":"divya","score":"850","comments":"10"},
    {"position":"3","name":"bhavya","score":"800","comments":"2"},
    {"position":"4","name":"chandu","score":"750","comments":"3"},
    {"position":"5","name":"keerthi","score":"700","comments":"5"},
    {"position":"6","name":"sravan","score":"650","comments":"6"},
    {"position":"7","name":"charan","score":"600","comments":"5"},
    {"position":"8","name":"varma","score":"550","comments":"3"},
    {"position":"9","name":"devi","score":"500","comments":"2"},
    {"position":"10","name":"dheeraj","score":"450","comments":"4"},

  ]
  questions=[
    {"q":"Multiplication of 2 strings"},
    {"q":"Addition of 2 strings"},
    {"q":"Multiplication of 2 mattrices"},
    {"q":"product of 2 integers"},
    {"q":"3 sum"},

  ]
  // displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  // dataSource = peoples;
  // clickedRows = new Set<People>();

  constructor() { 
    
  }

  ngOnInit(): void {
  }

}
