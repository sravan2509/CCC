import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-codeeditor',
  templateUrl: './codeeditor.component.html',
  styleUrls: ['./codeeditor.component.css']
})
export class CodeeditorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
