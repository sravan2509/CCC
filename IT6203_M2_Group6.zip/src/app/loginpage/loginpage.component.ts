import { Component, OnInit } from '@angular/core';
import { FormBuilder ,FormControlStatus,FormGroup,Validators} from '@angular/forms';


@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  loginForm!:FormGroup;
  submitted=false

  constructor(private fb:FormBuilder) { }

  ngOnInit(){
    this.loginForm=this.fb.group({
     
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required,Validators.minLength(8), Validators.maxLength(10)]
    });
  }
  get loginFormControl() {
    return this.loginForm.controls;
  }
onSubmit(){
  this.submitted=true
  if(this.loginForm.valid){
    return
  }

}
}
